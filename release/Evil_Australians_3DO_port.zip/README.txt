==========================
Evil Australians v1.1 3DO
==========================
Platforms : Windows, Linux (from source), Dreamcast, 3DO, GCW0

Evil Australians is a video game developed by me, gameblabla.
It's a platforming arena game made from scratch with the help of my own library, Gameblabla's Wrapper.
The game has several missions and in each mission, you are stuck in an arena where
you must defeat all the remaining enemies.
To defeat the enemies, you have a rapid-fire gun that can shoot several bullets at the same time.


==========
Story
==========

John, living in Australia, is an avid video game collector.
However, he learns from the news that the Australian government is soon going to ban video games.
John became furious : 
he grabs his weapons and swears vengeance on the government.

However 7 years ago, 
the government collected his own DNA as part of a secret project.
This secret project allowed the government to steal DNAs from all the aussies.
The Government learned of John's plan and they used his DNA to build an entire clone army of himself.

John is now facing an entire army of himself,
will he make it alive and finally kill the law ?


===========
Controls
===========

PC
X = Jump
C = Fire

You can also use a gamepad or a joystick to play.
